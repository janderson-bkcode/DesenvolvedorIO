var imgcheck = document.getElementById("img-checkbox")

function verificado() {
    var hasBeenClicked = imgcheck.style.display;

    if (hasBeenClicked =="none") {
        imgcheck.style.display = "block";
    } 
    else{
        imgcheck.style.display = "none";
    }
}

var impressora = document.getElementById('print')
var download = document.getElementById('download')

console.log(impressora)
console.log(download)