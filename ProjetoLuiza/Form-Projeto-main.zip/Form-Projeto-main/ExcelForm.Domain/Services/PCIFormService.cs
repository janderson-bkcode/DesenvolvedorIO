﻿
using ExcelForm.Domain.Interfaces.Repository;
using ExcelForm.Domain.Interfaces.Service;
using ExcelForm.Domain.Models.Entity;
using ExcelForm.Domain.Models.Request;
using ExcelForm.Domain.Models.Response;
using System.Collections.Generic;

namespace ExcelForm.Domain.Services
{
    public class PCIFormService : IPCIFormService
    {
        private readonly IPCIFormRepository _pCIFormRepository;
        public PCIFormService(IPCIFormRepository pCIFormRepository)
        {
            _pCIFormRepository = pCIFormRepository;   
        }

        public BaseResponse addAcceptance(FormPCIRequest request)
        {
            if (request.Accepted) return _pCIFormRepository.addAcceptance(request);

            BaseResponse response = new BaseResponse()
            {
                Code = 1,
                Message = "Você deve concordar com os termos acima!"
            };
            
            return response;    
        }

        public IEnumerable<UserAccept> getEveryAccept()
        {
            var response = _pCIFormRepository.getEveryAccept();
            return response;
        }
    }
}
