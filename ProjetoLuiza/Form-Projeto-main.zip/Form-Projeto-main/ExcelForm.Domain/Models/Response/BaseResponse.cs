﻿
namespace ExcelForm.Domain.Models.Response
{
    public class BaseResponse
    {
        public int Code { get; set; }
        public string Message { get; set; }
    }
}
