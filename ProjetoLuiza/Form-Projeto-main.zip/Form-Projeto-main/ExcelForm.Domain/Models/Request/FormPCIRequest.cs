﻿
namespace ExcelForm.Domain.Models.Request
{
    public class FormPCIRequest
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public bool Accepted { get; set; }
    }
}
