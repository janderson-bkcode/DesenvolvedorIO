﻿

using System;

namespace ExcelForm.Domain.Models.Entity
{
    public class UserAccept
    {
        public int IdAnswer { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public DateTime AcceptDate { get; set; }
    }
}
