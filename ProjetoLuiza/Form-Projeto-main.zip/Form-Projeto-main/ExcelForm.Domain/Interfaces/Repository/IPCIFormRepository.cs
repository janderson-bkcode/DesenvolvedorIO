﻿using ExcelForm.Domain.Models.Response;
using ExcelForm.Domain.Models.Request;
using ExcelForm.Domain.Models.Entity;
using System.Collections.Generic;

namespace ExcelForm.Domain.Interfaces.Repository
{
    public interface IPCIFormRepository
    {
        BaseResponse addAcceptance(FormPCIRequest request);
        IEnumerable<UserAccept> getEveryAccept();
    }
}
