﻿
using ExcelForm.Domain.Models.Entity;
using ExcelForm.Domain.Models.Request;
using ExcelForm.Domain.Models.Response;
using System.Collections.Generic;

namespace ExcelForm.Domain.Interfaces.Service
{
    public interface IPCIFormService
    {
        BaseResponse addAcceptance(FormPCIRequest request);
        IEnumerable<UserAccept> getEveryAccept();
    }
}
