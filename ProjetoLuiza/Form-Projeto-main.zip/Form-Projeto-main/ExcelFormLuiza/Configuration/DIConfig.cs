﻿

using ExcelForm.Infra.DbConnect;
using ExcelForm.Domain.Interfaces.Repository;
using ExcelForm.Domain.Interfaces.Service;
using ExcelForm.Infra.Repository;
using Microsoft.Extensions.DependencyInjection;
using ExcelForm.Domain.Services;

namespace ExcelForm.Configuration
{
    public static class DIConfig
    {
        public static IServiceCollection DependencyInjection(this IServiceCollection service)
        {
            service.AddScoped<DbSession>();
            //Services
            service.AddScoped<IPCIFormService, PCIFormService>();

            //Repositories
            service.AddScoped<IPCIFormRepository, PCIFormRepository>();
           


            return service;

        }
    }
}
