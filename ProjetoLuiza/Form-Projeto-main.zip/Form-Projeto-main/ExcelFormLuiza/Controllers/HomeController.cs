﻿using ClosedXML.Excel;
using ExcelForm.Domain.Interfaces.Service;
using ExcelFormLuiza.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;

namespace ExcelFormLuiza.Controllers
{
    public class HomeController : Controller
    {
        private readonly IPCIFormService _pciFormService;

        public HomeController(IPCIFormService pciFormService)
        {
            _pciFormService = pciFormService;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult TableAccept()
        {
            var users = _pciFormService.getEveryAccept();
            return View(users);

        }

        public IActionResult ExportExcel()
        {
            var users = _pciFormService.getEveryAccept();
            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(Common.ToDataTable(users.ToList()));
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "manual_aceites_termos.xlsx");
                }
            }
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }

    public static class Common
    {
        public static DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            dataTable.Columns.Add("COD");
            dataTable.Columns.Add("Nome Completo");
            dataTable.Columns.Add("Email");
            dataTable.Columns.Add("Data do aceite");
            //foreach (PropertyInfo prop in Props)
            //{
            //    //Setting column names as Property names
            //    dataTable.Columns.Add(prop.Name);
            //}
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }
    }
}
