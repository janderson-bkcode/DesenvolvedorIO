﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace ExcelForm.Infra.DbConnect
{
    public sealed class DbSession
    {
        public IDbConnection _connection;
        public IDbTransaction _transaction;

        public DbSession()
        {
            //Conexão Trabalho
            _connection = new SqlConnection("Data Source=DESKTOP-FH8RBBG\\SQLEXPRESS;Initial Catalog=FormularioTeste;TrustServerCertificate=True;Integrated Security=True");
            

        }
        
        public bool OpenConnection() 
        {
            try
            {
                if (_connection == null) 
                {
                    return false;
                }
                if(_connection.State != ConnectionState.Open)
                {
                    _connection.Open();
                    return true;
                } 

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        } 
        
        public bool CloseConnection()
        {
            try
            {
                if(_transaction != null)
                {
                    return false;
                }
                if(_connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                    return true;
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        
    }
}
