﻿
using ExcelForm.Infra.DbConnect;
using ExcelForm.Domain.Interfaces.Repository;
using ExcelForm.Domain.Models.Request;
using ExcelForm.Domain.Models.Response;
using Dapper;
using ExcelForm.Domain.Models.Entity;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ExcelForm.Infra.Repository
{
    public class PCIFormRepository : BaseRepository, IPCIFormRepository
    {
        public PCIFormRepository(DbSession session) : base(session)
        {
        }

        public BaseResponse addAcceptance(FormPCIRequest request)
        {
            BaseResponse response = new BaseResponse();

            string query = @"INSERT INTO AcceptanceFormPCI (FullName, Email, AcceptDate) 
                            values (@FullName, @Email, GETDATE())";

            try
            {
                if (_session.OpenConnection())
                {
                    int rows = _session._connection.Execute(query, 
                        param: new {
                            request.FullName,
                            request.Email
                        }, commandTimeout: 20);

                    if (rows > 0)
                    {
                        response.Code = 0;
                        response.Message = "Resposta gravada com sucesso!";

                    }
                    else
                    {
                        response.Code = 1;
                        response.Message = "Erro ao gravar resposta :c";
                    }
                }
            }
            catch (Exception ex)
            {
                response.Code = -1;
                response.Message = "Erro ao conectar ao banco de dados";
            }
            finally
            {
                _session.CloseConnection();
            }
            return response;
        }

        public IEnumerable<UserAccept> getEveryAccept()
        {
            List<UserAccept> response = new List<UserAccept>();

            string query = @"SELECT * FROM AcceptanceFormPCI";

            try
            {
                if (_session.OpenConnection())
                {
                    response = _session._connection.Query<UserAccept>(query, commandTimeout: 20).ToList();

                    if (response.Count > 0)
                    {
                        

                    }
                    else
                    {
                        
                    }
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                _session.CloseConnection();
            }
            return response;
        }
    }
}
