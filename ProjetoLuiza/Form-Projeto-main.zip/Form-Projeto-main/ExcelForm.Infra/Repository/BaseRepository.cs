﻿using ExcelForm.Infra.DbConnect;

namespace ExcelForm.Infra.Repository
{
    public abstract class BaseRepository 
    {
        public DbSession _session;

        public BaseRepository(DbSession session)
        {
            _session = session;
        }
    }
}
